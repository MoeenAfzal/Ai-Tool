#!/bin/bash

keyfile="~/.ssh/Project4.pem"
server="ubuntu@44.203.123.14"
dest="/var/www/44.203.123.14/"

echo "building app ..."
npm run build

echo "Deploying Files to server..."
scp -i "$keyfile" -r build/* "$server:$dest"

echo "Done!"