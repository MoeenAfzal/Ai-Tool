import Home from "./components/Home/Home"
import AboutPage from "./components/About/AboutPage"
import ContactPage from "./components/Contact/ContactPage"
import PolicyPage from "./components/Policy/PolicyPage"
import TermsPage from "./components/Terms/TermsPage"
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
// import { useState, useEffect } from "react";
import React, { useState, useEffect } from 'react';
import "./App.css"
import dark from './moon.png'
import bright from './brightness.png'
import abouttxt from './About.txt'
import contacttxt from './Contact.txt'
import Policytxt from './Policy.txt'
import termstxt from './Terms.txt'
// import { NavLink } from "react-router-dom";


function App() {
  const [isdark, setIsDark] = useState(false);
  const [isSticky, setSticky] = useState(false);

  const handleModeChange = () => {
    setIsDark(!isdark);
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleScroll = () => {
    if (window.scrollY > 0) {
      setSticky(true);
    } else {
      setSticky(false);
    }
  };

  return (
    <div className={!isdark ? "darkoverall" : "lightoverall"}>
      <div className="App">
        <div style={{ backgroundColor: isdark ? "white" : "black" }} className="nav-nav">
          <div className="toggle-switch">
            <img
              src={isdark ? dark : bright}
              alt="toggle"
              onClick={handleModeChange}
            />
          </div>
          <div className="nav-links">
            <BrowserRouter>
              <div className={!isdark ? "dark" : "light"}>
                <nav className={isSticky ? "sticky header1" : "aaa"}>
                  <NavLink
                    className="aa nav-link"
                    to="/Login"
                    activestyle={{
                      backgroundColor: isdark ? 'black' : 'white',
                      color: isdark ? 'white' : 'black',
                      border: `2px solid ${isdark ? 'white' : 'black'}`
                    }}
                    style={{
                      backgroundColor: isdark ? 'white' : 'black',
                      color: isdark ? 'black' : 'white',
                      border: `2px solid ${isdark ? 'black' : 'white'}`
                    }}
                  >
                    Login
                  </NavLink>
                  <NavLink
                    className="aa nav-link"
                    to="/Register"
                    activestyle={{
                      backgroundColor: isdark ? 'black' : 'white',
                      color: isdark ? 'white' : 'black',
                      border: `2px solid ${isdark ? 'white' : 'black'}`
                    }}
                    style={{
                      backgroundColor: isdark ? 'white' : 'black',
                      color: isdark ? 'black' : 'white',
                      border: `2px solid ${isdark ? 'black' : 'white'}`
                    }}
                  >
                    Register
                  </NavLink>
                </nav>
              </div>
            </BrowserRouter>
          </div>
        </div>
      </div>
      <BrowserRouter>
        <Routes>
          <Route exact path="/" element={<Home isdark={isdark} />} />
          <Route exact path="/about" element={<AboutPage isdark={isdark} />} />
          <Route exact path="/contact" element={<ContactPage isdark={isdark} />} />
          <Route exact path="/policy" element={<PolicyPage isdark={isdark} />} />
          <Route exact path="/terms" element={<TermsPage isdark={isdark} />} />
        </Routes>
        <div className={!isdark ? "dark" : "light"}>
          {/* <nav className={isSticky ? "sticky header" : "header"}> */}
          {/* <NavLink className="a" to="/">
            <a href="/path/to/terms.txt" target="_blank" rel="noopener noreferrer"> Home</a>
             
            </NavLink> */}

          {/* <a href={abouttxt} target="_blank" rel="noopener noreferrer"> About</a>



            <a href={contacttxt} target="_blank" rel="noopener noreferrer">Contact</a>



            <a href={Policytxt} target="_blank" rel="noopener noreferrer"> Policy</a>



            <a href={termstxt} target="_blank" rel="noopener noreferrer">Terms</a> */}

          {/* </nav> */}

          <nav className={isSticky ? "sticky header" : "header"}>
            <NavLink
              to="/"
              activeclassname="active"
              className="nav-link"
            >
              Home
            </NavLink>
            <a href={abouttxt}  rel="noopener noreferrer"> About</a>



<a href={contacttxt}  rel="noopener noreferrer">Contact</a>



<a href={Policytxt}  rel="noopener noreferrer"> Policy</a>



<a href={termstxt} rel="noopener noreferrer">Terms</a>
          </nav>
        </div>
      </BrowserRouter >
    </div >
  );
}


export default App;
