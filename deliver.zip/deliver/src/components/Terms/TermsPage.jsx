import React from "react";
import "./TermsPage.css"

const TermsPage = (props) => {
  return (
    <>
      <div className={!props.isdark ? "about-container-dark" : "about-container"}>
        <h1>About Us</h1>
        <p className="terms">
          Terms & Conditions.
        </p>
        <p>
          You MUST be over 18 years old to use this service to create #NSFW content
          You MUST NOT use this service to create content that is illegal in the UK / US.
        </p>
        <p>
          AIGEP AI Generated Ethical Porn
          Our goal is to create NSFW content that is free from exploitation.
          Our priority is to exclude content that depicts minors as well as illegal and harmful acts.
          “ALL FUN - NO KIDS - NO HARM”
          ALL FUN. #NSFW all the way!
          NO KIDS. No depictions of underage persons.
        </p>
        <p>
          NO HARM. No depictions of persons being harmed physically, emotionally or psychologically.
          Replacing real-life pornography with artificially generated content has the potential to bring about
          several positive changes, including the elimination of exploitation and sex-trafficking, improved
          body image, more control over content, decreased risk of exposure to harmful material, and the
          reduction of negative attitudes and stereotypes. It is important to consider it as part of a
          comprehensive approach to addressing the harm and exploitation that is prevalent in the porn
          industry.
        </p>
        <div className="links">
          <a target="_blank" href="">Terms</a>
          <a target="_blank" href="">Policy</a>
        </div>
      </div>

    </>

  );
};

export default TermsPage;
