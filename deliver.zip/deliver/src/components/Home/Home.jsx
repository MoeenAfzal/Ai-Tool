import React, { useState } from "react";
import "./Home.css";
import logo from "./logo.png"
import {  NavLink } from 'react-router-dom';

function Home(props) {
  const [error, setError] = useState(null);
  const [ntext, setNText] = useState("");
  const [image, setImage] = useState(null);
  const [text, setText] = useState("");
  const [isChecked, setIsChecked] = useState(false);
  const [isCheckedRemember, setIsCheckedRemember] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedValue, setSelectedValue] = useState("deliberate");
  const [Again, setAgain] = useState(true);
  const [gscale, setGscale] = useState(7.5);
  // const [denoise, setDenoise] = useState(6.5);
  const [seed, setSeed] = useState(Math.floor(Math.random() * 10001));
  const [steps, setSteps] = useState(35);
  const [scheduler, setScheduler] = useState("DPM");

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
    // console.log(selectedValue)
  };

  const handleSchedulerChange = (event) => {
    setScheduler(event.target.value);
    // console.log(scheduler)
  };
  function handleSecondChange(e) {
    nTextChange(e)
  }
  const handleSeedChange = (event) => {
    setSeed(parseInt(event.target.value));
    // console.log(seed);
    handleSecondChange(event)
  };

  const handleSChange = (event) => {
    setSteps(parseInt(event.target.value));
  };

  // const handleDenoiseChange = (event) => {
  //   setDenoise(parseInt(event.target.value));
  // };

  const handleGChange = (event) => {
    setGscale(parseFloat(event.target.value));
    // if (gscale > 15) {
    //   setError("Kindly Enter Guidance Scale Between 1 to 15");
    // } else {
    //   setError(null);
    // }
  };
  const { isDark } = props;
  const handleTryAgain = () => {
    setImageLoaded(false);
  };

  const textChange = (e) => {
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = textarea.scrollHeight + "px";
    setText(e.target.value);
  };

  const nTextChange = (e) => {
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = textarea.scrollHeight + "px";
    setNText(e.target.value);
  };

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
  };

  const handleCheckboxRememberChange = () => {
    setIsCheckedRemember(!isCheckedRemember);
  };

  const surpriseClick = async (event) => {
    event.preventDefault();
    setAgain(false);
    setIsLoading(true);
    setError(null);

    if (gscale > 15) {
      setIsLoading(false);
      setError("Kindly Enter Guidance Scale Between 1 to 15");
    } else {
      const timeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => {
          reject(new Error("Timeout occurred"));
        }, 120000); // 60 seconds
      });
      // img
      // const authHeader =
      //   "Basic " +
      //   btoa(
      //     process.env.REACT_APP_USERNAME + ":" + process.env.REACT_APP_PASSWORD
      //   );

      const responsePromise = fetch(process.env.REACT_APP_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Authorization: authHeader,
        },
        body: JSON.stringify({
          prompt: "None",
          nprompt: "None",
          model: selectedValue,
          // "denoise" : denoise,
          gscale: gscale,
          seed: seed,
          steps: steps,
          scheduler: scheduler
        }),
      });

      try {
        const response = await Promise.race([responsePromise, timeoutPromise]);

        if (response.ok) {
          const data = await response.json();
          // console.log(data.image)
          const base64String = `data:image/png;base64,${data.image}`;

          const byteCharacters = atob(base64String.split(",")[1]);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          const blob = new Blob([byteArray], { type: "image/png" });
          const imageUrl = URL.createObjectURL(blob);

          setImage(imageUrl);
          setImageLoaded(true);
          if (!isCheckedRemember) {
            setText("");
            setNText("");
            setSeed(Math.floor(Math.random() * 10001));
            // setDenoise(6.5);
            setGscale(6.5);
          }
          setAgain(true);
          setIsLoading(false);
        } else {
          throw new Error(`Response status not OK: ${response.status}`);
        }
      } catch (error) {
        setError(error.toString());
        setIsLoading(false);
        if (!isCheckedRemember) {
          setText("");
          setNText("");
          setSeed(Math.floor(Math.random() * 10001));
          // setDenoise(6.5);
          setGscale(6.5);
          setSteps(35);
        }
        setImage(null);
        setImageLoaded(false);
        setAgain(true);
      }
    }
  };

  const handleDownload = () => {
    const link = document.createElement("a");
    link.download = "sd-generated-image.png";
    link.href = image;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setAgain(false);
    setIsLoading(true);
    setError(null);
    // console.log(isLoading)
    if (gscale > 15) {
      setIsLoading(false);
      setError("Kindly Enter Guidance Scale Between 1 to 15");
    } else {
      const timeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => {
          reject(new Error("Timeout occurred"));
        }, 120000); // 60 seconds
      });

      // const authHeader =
      //   "Basic " +
      //   btoa(
      //     process.env.REACT_APP_USERNAME + ":" + process.env.REACT_APP_PASSWORD
      //   );

      const responsePromise = fetch(process.env.REACT_APP_API_URL, {
        // const responsePromise = fetch('http://127.0.0.1:5000/download', {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Authorization: authHeader,
        },
        body: JSON.stringify({
          prompt: text,
          nprompt: ntext,
          model: selectedValue,
          // "denoise" : denoise,
          gscale: gscale,
          seed: seed,
          steps: steps,
          scheduler: scheduler
        }),
      });

      try {
        const response = await Promise.race([responsePromise, timeoutPromise]);

        if (response.ok) {
          const data = await response.json();
          // console.log(data.image)
          const base64String = `data:image/png;base64,${data.image}`;

          const byteCharacters = atob(base64String.split(",")[1]);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          const blob = new Blob([byteArray], { type: "image/png" });
          const imageUrl = URL.createObjectURL(blob);

          setImage(imageUrl);
          setImageLoaded(true);
          if (!isCheckedRemember) {
            setText("");
            setNText("");
            setSeed(Math.floor(Math.random() * 10001));
            // setDenoise(6.5);
            setGscale(6.5);
          }
          setIsLoading(false);
          setAgain(true);
        } else {
          throw new Error(`Response status not OK: ${response.status}`);
        }
      } catch (error) {
        setError(error.toString());
        setIsLoading(false);
        if (!isCheckedRemember) {
          setText("");
          setNText("");
          setSeed(Math.floor(Math.random() * 10001));
          // setDenoise(6.5);
          setGscale(6.5);
          setSteps(35);
        }
        setImage(null);
        setImageLoaded(false);
        setAgain(true);
      }
    }
  };

  return (
    <>
      {/* {console.log(process.env.REACT_APP_API_URL.toString())} */}
      <div className={!props.isdark ? "home-dark" : "home"}>
        {imageLoaded && Again ? (
          <img className="generated-image" src={image} alt="generated"></img>
        ) : isLoading ? (
          <>
            <div className="logo">
              <h1>
                <img src={logo} alt="logo"></img>
              </h1>
            </div>
            <h1 className="loading blink">AI AT WORK</h1>
          </>
        ) : error ? (
          <>

            <div className="logo">

              <h1>
                <img src={logo} alt="logo"></img>
              </h1>
            </div>
            <h1 className="error">{error}</h1>
            <div className="form">
              <textarea
                value={text}
                onChange={(e) => textChange(e)}
                placeholder="what you want to see "
              ></textarea>
            </div>
            {isChecked ? (
              <div id="text-area">
                <textarea
                  value={ntext}
                  onChange={(e) => nTextChange(e)}
                  placeholder="what you don't want to see"
                ></textarea>
              </div>
            ) : null}
            <div className="neg-ab"><div className="negative">
              <input
                type="checkbox"
                checked={isChecked}
                id="toggle-negative"
                onChange={handleCheckboxChange}
              ></input>
              <label htmlFor="toggle-negative">Negative  Prompt</label>
            </div>
              <div className="negative">
                <input
                  type="checkbox"
                  checked={isCheckedRemember}
                  id="toggle-textarea"
                  onChange={handleCheckboxRememberChange}
                ></input>
                <label htmlFor="toggle-textarea">Remember Prompt</label>
              </div></div>

            <div className="moment1">
              <div className="model-select">
                <label htmlFor="selector">Model:</label>
                <select
                  id="selector"
                  value={selectedValue}
                  onChange={handleSelectChange}
                >
                  <option value="deliberate">General</option>
                  <option value="uber">Hardcore</option>
                  <option value="realistic">Realistic</option>
                </select>
              </div>
              <div className="model-select">
                <label htmlFor="selector">Scheduler:</label>
                <select
                  id="selector"
                  value={scheduler}
                  onChange={handleSchedulerChange}
                >
                  <option value="DPM">DPM</option>
                  <option value="heun">Heun</option>
                  <option value="euler">Euler</option>
                  <option value="DDIMINV">DDIM_INV</option>
                  <option value="KDPM2">KDPM2</option>
                </select>
              </div>
              {/* DPMSolverMultistepScheduler, HeunDiscreteScheduler, KDPM2AncestralDiscreteScheduler, DDIMInverseScheduler, EulerAncestralDiscreteScheduler */}
              <div className="CFG">
                <label htmlFor="gscale">Gscale:</label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  step="0.5"
                  id="gscale"
                  value={gscale}
                  onChange={handleGChange}
                />
                {/* <p>{gscale}</p> */}
              </div>
              <div className="seed">
                <label htmlFor="seed">Seed:</label>
                <input
                  type="number"
                  id="number"
                  value={seed}
                  onChange={handleSeedChange}
                ></input>
              </div>
              <div className="steps">
                <label htmlFor="steps">Steps:</label>
                <input type="number" id="steps" value={steps} onChange={handleSChange}></input>
              </div>
            </div>
            {/* <p>You have selected: {selectedValue}</p> */}
          </>
        ) : (
          <>
            <div className="logo">
              <h1>
              <NavLink
              to="/"
              activeclassname="active"
              className="nav-link"
            >
            <img src={logo} alt="logo"></img>
            </NavLink>
                
              </h1>
            </div>
            <div className="form">
              <textarea
                value={text}
                onChange={(e) => textChange(e)}
                placeholder="what you want to see"
              ></textarea>
            </div>
            {isChecked ? (
              <div id="text-area">
                <textarea
                  value={ntext}
                  onChange={(e) => nTextChange(e)}
                  placeholder="what you don't want to see"
                ></textarea>
              </div>
            ) : null}
            <div className="first-row"><div className="negative">
             
              <label htmlFor="toggle-negative">Negative Prompt</label>
              <input
                type="checkbox"
                checked={isChecked}
                id="toggle-negative"
                onChange={handleCheckboxChange}
                
              ></input>
            </div>
            <div className="negative">
              
              <label htmlFor="toggle-textarea">Remember Prompt</label>
              <input
                type="checkbox"
                checked={isCheckedRemember}
                id="toggle-textarea"
                onChange={handleCheckboxRememberChange}
              ></input>
            </div>
            <div className="model-select">
                <label htmlFor="selector">Model:</label>
                <select
                  id="selector"
                  value={selectedValue}
                  onChange={handleSelectChange}
                >
                  <option value="deliberate">General</option>
                  <option value="uber">Hardcore</option>
                  <option value="realistic">Realistic</option>
                </select>
              </div></div>
            
            <div className="moment1">
              
              <div className="model-select">
                <label htmlFor="selector">Sampler:</label>
                <select
                  id="selector"
                  value={scheduler}
                  onChange={handleSchedulerChange}
                >
                  <option value="DPM">DPM</option>
                  <option value="heun">Heun</option>
                  <option value="euler">Euler</option>
                  <option value="DDIMINV">DDIM_INV</option>
                  <option value="KDPM2">KDPM2</option>
                </select>
              </div>
              <div className="CFG">
                <label htmlFor="gscale">CFG:</label>
                <input
                  type="number"
                  id="gscale"
                  min="0"
                  max="15"
                  step="0.5"
                  value={gscale}
                  onChange={handleGChange}
                />
                {/* <p className="gscale">{gscale}</p> */}
              </div>
              <div className="seed">
                <label htmlFor="seed">Seed:</label>
                <input
                  type="number"
                  id="number"
                  value={seed}
                  onChange={handleSeedChange}
                  // onChange={(e) => nTextChange(e)}
                 
                ></input>
                
              </div>
              <div className="steps">
                <label htmlFor="steps">Steps:</label>
                <input type="number" id="steps" value={steps} onChange={handleSChange}></input>
              </div>
            </div>

            {/* </div> */}
            {/* // </div> */}
          </>
        )}
        {imageLoaded ? (
          !isLoading ? (
            <div className="buttons">
              {/* <button className="btn-1" onClick={surpriseClick}>
                Random
              </button> */}
              <button className="btn-1" onClick={handleTryAgain}>
                Go Back
              </button>
              <button className="btn-2" onClick={handleDownload}>
                Download
              </button>
            </div>
          ) : (
            // <div className="buttons">
            //   <button className="btn-1" onClick={handleSubmit}>Variation</button>
            //   <button className="btn-1" onClick={handleTryAgain}>Try Again</button>
            //   <button className="btn-2" onClick={handleDownload}>Download</button>
            // </div>
            <div className="buttons">
              {/* <button
                className="btn-1 disabled"
                disabled={true}
                onClick={surpriseClick}
              >
                Random
              </button> */}
              <button
                className="btn-1 disabled"
                disabled={true}
                onClick={handleTryAgain}
              >
                Go Back
              </button>
              <button
                className="btn-2 disabled"
                disabled={true}
                onClick={handleDownload}
              >
                Download
              </button>
            </div>
          )
        ) : isLoading ? (
          <div className="buttons">
            <button
              className="btn-1 disabled"
              disabled={true}
              onClick={handleSubmit}
            >
              Generate
            </button>
            <button
              className="btn-2 disabled"
              disabled={true}
              onClick={surpriseClick}
            >
              Random
            </button>
          </div>
        ) : (
          <div className="buttons">
            <button className="btn-1" onClick={handleSubmit}>
              Generate
            </button>
            <button className="btn-2" onClick={surpriseClick}>
              Random
            </button>
          </div>
        )}
      </div>
    </>
  );
}

export default Home;
