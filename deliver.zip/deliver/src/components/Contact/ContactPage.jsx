import React from 'react';
import './ContactPage.css';

const ContactPage = () => {

  return (
    <>
    <div className="about-container" >
      <h1>Contact Us</h1>
      <p className='terms'>For contact kindly mail us : S3Xaix@gmail.com</p>
    </div>
    </>
  );
};

export default ContactPage;
